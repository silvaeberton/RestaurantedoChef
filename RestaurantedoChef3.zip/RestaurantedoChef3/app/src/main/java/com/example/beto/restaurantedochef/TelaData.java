package com.example.beto.restaurantedochef;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.annotation.VisibleForTesting;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.Toast;

import java.text.SimpleDateFormat;

public class TelaData extends AppCompatActivity {

    CalendarView calendario;
    String dataSelecionada;
    int ano;
    int mes;
    int dia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_data);
        setTitle("Selecione a data");

        calendario = findViewById(R.id.calendarView);
        calendario.setMinDate(System.currentTimeMillis());

        final long milisegundos = System.currentTimeMillis();
        final SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");


        calendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                ano = year;
                mes = month;
                dia = dayOfMonth;
                
                Toast.makeText(getApplicationContext(), sdf.format(milisegundos), Toast.LENGTH_SHORT).show();
                //Toast.makeText(getApplicationContext(),dia + "/" + (mes + 1) + "/" + ano,Toast.LENGTH_SHORT).show();
            }
        });

    }

    public void chamaTelaMesas(View view){
        Intent intent = new Intent(this,TelaMesas.class);
        startActivity(intent);
    }
}
