package com.example.beto.restaurantedochef;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TelaMesas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_mesas);

        setTitle("Mesas");
    }
}
