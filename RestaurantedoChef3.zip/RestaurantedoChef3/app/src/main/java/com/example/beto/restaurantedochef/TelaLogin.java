package com.example.beto.restaurantedochef;

import android.content.Intent;
import android.graphics.Shader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class TelaLogin extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_login);

        setTitle("Login");

    }

    public void login(View view){
        Intent intent = new Intent(this, TelaPrincipal.class);
        startActivity(intent);
    }

    public void cadastrarUsuario(View view){
        Intent intent = new Intent(this, TelaCadastro.class);
        startActivity(intent);
    }

    public void esqueciSenha(View view){
        Toast.makeText(this,"Enviado para email",Toast.LENGTH_SHORT).show();
    }
}
